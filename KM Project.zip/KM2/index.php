
﻿<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
		
		<style>
			body {
			background-image: url('../header_new.jpg');
			background-repeat: no-repeat;
			background-attachment: fixed;
			background-size: 100% 100%;
}
</style>

        <!--favicon-->
        <link rel="shortcut icon" href="favicon.ico" type="image/icon">
        <link rel="icon" href="favicon.ico" type="image/icon">
        <title>PES Home</title>
        <!-- Bootstrap Core CSS -->
        <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
        <!-- Footer -->
        <link type="text/css" rel="stylesheet" href="css/style.css">
        <!-- Custom Fonts -->
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800'
        rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic'
        rel='stylesheet' type='text/css'>
        <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css" type="text/css">
        <!-- Plugin CSS -->
        <link rel="stylesheet" href="css/animate.min.css" type="text/css">
        <!-- Custom CSS -->
        <link rel="stylesheet" href="css/creative.css" type="text/css">
        
    </head>
	
	

    <body id="page-top" style="background-image: url('header_new.jpg');">

        <nav id="mainNav" class="navbar navbar-default navbar-fixed-top" style="background:black">
            <div class="container-fluid">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">

                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand page-scroll" href="http://www.pes.edu">PES UNIVERSITY</a>
                </div>
				
				<style>

</style>
                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                        <li>
                            <a class="page-scroll" href="./student/login.php">Student Login</a>
                        </li>

                        <li>
                            <a class="page-scroll" href="./companies/login.php">Company Login</a>
                        </li>
                        <li>
                            <a class="page-scroll" href="./admin/login.php">Administrative Login</a>
                        </li>
                    </ul>

            </div>
               
            </div>
            
        </nav>
		
                <header>
				
            <div class="header-content">
                <div class="header-content-inner">
                    <h1 style = "color: white;">PLACEMENT MANAGEMENT SYSTEM</h1>
                    <hr>
                    <p style = "color: white;">We are here to Build your Skills and Career with our Driven Passion and Reality.<br> 
					 Bright future awaits you here..Join us now..</p>
                </div>
            
			</div>
        </header>
    <?php include 'footer.php' ?>
    </body>

</html>

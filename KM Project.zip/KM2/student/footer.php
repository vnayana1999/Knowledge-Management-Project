<div class="footer">
  <div class="container">
    <div class="col-md-3 ftr_navi ftr">
      <h3>NAVIGATION</h3>
      <ul>
        <li>
          <a href="../index.php">Home</a>
        </li>
        <li>
          <a href="../student/login.php">Student Login</a>
        </li>
        <li>
          <a href="../companies/login.php">Company Login</a>
        </li>

        <li>
          <a href="../admin/login.php">Admin Login</a>
        </li>
      </ul>
    </div>
    
	
    <div class="col-md-3 get_in_touch ftr">
      <h3>GET IN TOUCH</h3>
      <p>100 Feet Ring Road,</p>
      <p>BSK III Stage,</p>
	  <p>Bangalore-560085</p><br/>
      <p>+91 80 26721983,</p>
	  <p>+91 80 26722108
</p>
      <a href="mailto:admissions@pes.edu">admissions@pes.edu</a>
    </div>
    <div class="col-md-3 get_in_touch ftr">

    </div>
    
    </div>

  </div>
